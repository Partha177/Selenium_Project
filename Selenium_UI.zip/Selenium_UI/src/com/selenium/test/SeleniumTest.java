package com.selenium.test;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SeleniumTest {
	public static void main(String args[]) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", ".\\driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//RadioButton
		driver.findElement(By.xpath("//input[@value='radio1']")).click();
		Thread.sleep(2000);
		
		// Checkbox
		driver.findElement(By.id("checkBoxOption1")).click();
        // Thread.sleep(2000);
		String text= driver.findElement(By.xpath("//div[@id='checkbox-example']//label[1]")).getText();
		System.out.println("CheckBox Text"+text);
		Thread.sleep(2000);
		
		// Dropdown
		Select s=new Select(driver.findElement(By.id("dropdown-class-example")));
		s.selectByVisibleText(text);
		Thread.sleep(2000);
		
		//INputBox
		WebElement input = driver.findElement(By.id("name"));
		input.sendKeys(text);
		Thread.sleep(2000);
		driver.findElement(By.id("alertbtn")).click();
        Thread.sleep(2000);
		
		//ALert dialog to close
		Alert alert= driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();
		Thread.sleep(2000);

		
		Actions a= new Actions(driver);
		a.moveToElement(driver.findElement(By.id("mousehover"))).build().perform();
		Thread.sleep(2000);
        a.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Top')]"))).click().build().perform();
        Thread.sleep(4000);
		
		driver.close();
		driver.quit();
	}
}
